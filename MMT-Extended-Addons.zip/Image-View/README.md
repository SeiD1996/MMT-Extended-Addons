# Image-Display - Shows an image file at beginning of install

## Instructions:
* Put your picture file in the addon folder
* Call the image_view function wherever you want the image displayed
  * Example: image_view image.jpg
  * Note that you do NOT put the path to the picture in the call, just the filename

## Credits:
* By Ziona @ XDA-Developers
